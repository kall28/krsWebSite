﻿//var strURL = "http://localhost:50111/Web.Display/";
var strURL = "http://localhost:51560/";