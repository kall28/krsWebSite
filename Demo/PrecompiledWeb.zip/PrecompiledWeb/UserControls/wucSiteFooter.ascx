﻿<%@ control language="C#" autoeventwireup="true" inherits="New_UserControls_wucSiteFooter, App_Web_wucsitefooter.ascx.6bb32623" %>

<footer class="modal-footer ftHdr" id="FootNav">
    <div id="myNavbar" class="collapse navbar-collapse footer">
        <ul id="fnav">
            <li class="cnecttus">About Us
   
                        <ul>
                            <li><a href="#" onclick="javascript: link_click('AU'); return false;">Profile</a></li>
                        </ul>
            </li>
            <li class="cnecttus">Help
   
                        <ul>
                            <li><a href="#" onclick="javascript:link_click('FAQs');return false;">FAQ</a></li>
                            <%--<li><a href="#" onclick="javascript:link_click('TFN');return false;">Toll free numbers</a></li>--%>
                            <%--<li><a href="#">Live chat</a></li>--%>
                        </ul>
            </li>
            <li class="cnecttus">Policies
   
                        <ul>
                            <li><a href="#" onclick="javascript:link_click('TNC');return false;">T&amp;C </a></li>
                            <li><a href="#" onclick="javascript:link_click('Policy');return false;">Privacy Policy</a></li>
                            <li><a href="#" onclick="javascript:link_click('Disclaimer');return false;">Disclaimer</a></li>
                        </ul>
            </li>
            <li class="cnecttus">Connect with us
   
                        <ul>
                            <li><a href="#" onclick="javascript:link_click('CU');return false;">Contact Us</a>
                            </li>
                            <li class="social">
                                <script src="//platform.linkedin.com/in.js" type="text/javascript"> lang: en_US</script>
                                <script type="IN/FollowCompany" data-id="9267366"></script>
                                <script src="https://apis.google.com/js/platform.js"></script>
                                <div class="g-ytsubscribe" data-channelid="UCXvDg3EghSKTLHEovZYHrPA" data-layout="default" data-count="hidden"></div>
                                <%--<div class="g-ytsubscribe" data-channelid="UCIJSXrlpyJutzsz55qXqeMA" data-layout="default" data-count="hidden"></div>--%>
                                    <%--<a href="https://www.youtube.com/channel/UCIJSXrlpyJutzsz55qXqeMA?nohtml5=False" target="_blank">
                                    <img id="imgFB" runat="server" src="~/images/ico-fb.png" /></a>--%>
                                    <%--<script src="https://apis.google.com/js/platform.js"></script>
                                    <div class="g-ytsubscribe" data-channelid="UCIJSXrlpyJutzsz55qXqeMA" data-layout="default" data-theme="dark" data-count="hidden"></div>--%>
                                    <%--<a href="https://www.linkedin.com/company/9267366?trk=tyah&trkInfo=clickedVertical%3Acompany%2Cidx%3A2-2-3%2CtarId%3A1429780256491%2Ctas%3Ainfinia%20"
                                        target="_blank">
                                    <img id="imgIn" runat="server" src="~/images/ico-in.png" /></a>--%></li>
                                <%--<a href="#" onclick="javascript:link_click('CNT');return false;"><img id="imgIn" runat="server" src="~/images/ico-in.png" /></a>--%>                                
                            </li>
                        </ul>

            </li>
            <li class="pwrdLogo">
                <a href="http://www.infiniacs.com/" target="_blank">
                    <img id="imgLogo" runat="server" src="~/images/infilogo.jpg" />
                </a>
            </li>
            <div class="clr"></div>
        </ul>
    </div>
    <a href="http://www.infiniacs.com/" class="pwrdlogoMob" target="_blank">
        <img id="img1" runat="server" src="~/images/infilogo.jpg" />
    </a>
    <p>Copyright 2016. All rights reserved.</p>
</footer>
