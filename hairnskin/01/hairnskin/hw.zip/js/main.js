$(function () {
    $("#head").load("head.html");
    $("#header").load("header.html");
    $("#footer").load("footer.html");
});
